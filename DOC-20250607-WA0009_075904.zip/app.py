import os
import secrets
from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

# Initialize Flask app
app = Flask(__name__)

# Production settings - secure secret key and disable debug
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', secrets.token_hex(16))
app.config['DEBUG'] = False

# Database configuration - Using SQLite for simplicity
# Store database in a persistent location
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///rishikesh_platform.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
from models.user import db
db.init_app(app)

# Initialize login manager
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.init_app(app)

# Import models
from models.user import User
from models.listing import Category, Listing, ListingImage
from models.booking import Booking
from models.review import Review

# User loader for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Register blueprints
from routes.main import main_bp
from routes.auth import auth_bp
from routes.listings import listings_bp
from routes.bookings import bookings_bp
from routes.admin import admin_bp

app.register_blueprint(main_bp)
app.register_blueprint(auth_bp, url_prefix='/auth')
app.register_blueprint(listings_bp, url_prefix='/listings')
app.register_blueprint(bookings_bp, url_prefix='/bookings')
app.register_blueprint(admin_bp, url_prefix='/admin')

# Create database tables
with app.app_context():
    db.create_all()
    
    # Check if we already have categories
    if Category.query.count() == 0:
        # Create default categories
        categories = [
            Category(name='River Rafting', description='Experience thrilling white water rafting on the Ganges'),
            Category(name='Yoga Retreats', description='Find peace and balance with yoga sessions by the Ganges'),
            Category(name='Trekking', description='Explore the beautiful mountains and forests around Rishikesh'),
            Category(name='Camping', description='Camp under the stars by the riverside'),
            Category(name='Spiritual Tours', description='Visit temples and ashrams to experience the spiritual side of Rishikesh')
        ]
        
        db.session.add_all(categories)
        db.session.commit()
        print("Database initialized with default categories.")

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

# Simple route for testing
@app.route('/test')
def test():
    return "Rishikesh Experience Platform is running!"

if __name__ == '__main__':
    # For local development only
    app.run(host='0.0.0.0', port=5000, debug=True)
else:
    # For production WSGI servers
    # Debug mode should be off in production
    app.debug = False
