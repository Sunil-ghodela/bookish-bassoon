#!/bin/bash

# Navigate to the project directory
cd /home/ubuntu/rishikesh_platform

# Run the Flask application
python app.py
