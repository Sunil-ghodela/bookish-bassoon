#!/bin/bash

# Create a requirements.txt file for deployment
pip freeze > /home/ubuntu/rishikesh_platform/requirements.txt

# Ensure the instance directory exists and is writable
mkdir -p /home/ubuntu/rishikesh_platform/instance
chmod 755 /home/ubuntu/rishikesh_platform/instance

# Create a production-ready WSGI file
cat > /home/ubuntu/rishikesh_platform/wsgi.py << 'EOF'
from app import app

if __name__ == "__main__":
    app.run()
EOF

echo "Production deployment preparation complete!"
