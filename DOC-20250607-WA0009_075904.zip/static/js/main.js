// Main JavaScript for Rishikesh Experience Platform

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Booking form calculation
    const bookingForm = document.getElementById('booking-form');
    if (bookingForm) {
        const numPeopleSelect = document.getElementById('num_people');
        const pricePerPerson = document.getElementById('price-per-person');
        const totalPriceDisplay = document.getElementById('total-price');
        
        if (numPeopleSelect && pricePerPerson && totalPriceDisplay) {
            const updateTotalPrice = function() {
                const numPeople = parseInt(numPeopleSelect.value);
                const price = parseFloat(pricePerPerson.dataset.price);
                const totalPrice = numPeople * price;
                totalPriceDisplay.textContent = '₹' + totalPrice.toFixed(2);
            };
            
            numPeopleSelect.addEventListener('change', updateTotalPrice);
            updateTotalPrice(); // Initial calculation
        }
    }
});
