#!/bin/bash

# Start Gunicorn with 4 worker processes
# Bind to all interfaces on port 5000
# Use the wsgi.py file as the entry point
cd /home/ubuntu/rishikesh_platform
gunicorn --workers=4 --bind=0.0.0.0:5000 wsgi:app
