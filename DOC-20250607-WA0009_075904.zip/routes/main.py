from flask import Blueprint, render_template, request
from models.listing import Listing, Category

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    featured_listings = Listing.query.limit(6).all()
    categories = Category.query.all()
    return render_template('index.html', featured_listings=featured_listings, categories=categories)

@main_bp.route('/about')
def about():
    return render_template('about.html')

@main_bp.route('/contact')
def contact():
    return render_template('contact.html')
