from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from models.listing import Listing, Category
from models.user import db

listings_bp = Blueprint('listings', __name__)

@listings_bp.route('/')
def index():
    category_id = request.args.get('category', type=int)
    if category_id:
        listings = Listing.query.filter_by(category_id=category_id).all()
        category = Category.query.get_or_404(category_id)
        return render_template('listings/index.html', listings=listings, category=category)
    else:
        listings = Listing.query.all()
        return render_template('listings/index.html', listings=listings)

@listings_bp.route('/<int:id>')
def show(id):
    listing = Listing.query.get_or_404(id)
    return render_template('listings/show.html', listing=listing)

@listings_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    if current_user.user_type not in ['vendor', 'admin']:
        flash('You do not have permission to create listings.')
        return redirect(url_for('listings.index'))
        
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        price = request.form.get('price')
        location = request.form.get('location')
        duration = request.form.get('duration')
        category_id = request.form.get('category_id')
        
        new_listing = Listing(
            title=title,
            description=description,
            price=float(price),
            location=location,
            duration=duration,
            category_id=category_id,
            vendor_id=current_user.id
        )
        
        db.session.add(new_listing)
        db.session.commit()
        
        flash('Listing created successfully!')
        return redirect(url_for('listings.show', id=new_listing.id))
        
    categories = Category.query.all()
    return render_template('listings/create.html', categories=categories)
