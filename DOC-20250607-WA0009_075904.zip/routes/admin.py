from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from models.user import User
from models.listing import Listing, Category
from models.booking import Booking
from models.user import db

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/')
@login_required
def index():
    if current_user.user_type != 'admin':
        flash('Access denied.')
        return redirect(url_for('main.index'))
        
    user_count = User.query.count()
    listing_count = Listing.query.count()
    booking_count = Booking.query.count()
    recent_bookings = Booking.query.order_by(Booking.created_at.desc()).limit(5).all()
        
    return render_template('admin/index.html', 
                          user_count=user_count,
                          listing_count=listing_count,
                          booking_count=booking_count,
                          recent_bookings=recent_bookings)

@admin_bp.route('/users')
@login_required
def users():
    if current_user.user_type != 'admin':
        flash('Access denied.')
        return redirect(url_for('main.index'))
        
    users = User.query.all()
    return render_template('admin/users.html', users=users)

@admin_bp.route('/listings')
@login_required
def listings():
    if current_user.user_type != 'admin':
        flash('Access denied.')
        return redirect(url_for('main.index'))
        
    listings = Listing.query.all()
    return render_template('admin/listings.html', listings=listings)

@admin_bp.route('/bookings')
@login_required
def bookings():
    if current_user.user_type != 'admin':
        flash('Access denied.')
        return redirect(url_for('main.index'))
        
    bookings = Booking.query.all()
    return render_template('admin/bookings.html', bookings=bookings)

@admin_bp.route('/categories', methods=['GET', 'POST'])
@login_required
def categories():
    if current_user.user_type != 'admin':
        flash('Access denied.')
        return redirect(url_for('main.index'))
        
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        
        new_category = Category(name=name, description=description)
        db.session.add(new_category)
        db.session.commit()
        
        flash('Category added successfully!')
        return redirect(url_for('admin.categories'))
        
    categories = Category.query.all()
    return render_template('admin/categories.html', categories=categories)
