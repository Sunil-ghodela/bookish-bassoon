from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from models.booking import Booking
from models.listing import Listing
from models.user import db
from datetime import datetime

bookings_bp = Blueprint('bookings', __name__)

@bookings_bp.route('/')
@login_required
def index():
    bookings = Booking.query.filter_by(user_id=current_user.id).all()
    return render_template('bookings/index.html', bookings=bookings)

@bookings_bp.route('/create/<int:listing_id>', methods=['GET', 'POST'])
@login_required
def create(listing_id):
    listing = Listing.query.get_or_404(listing_id)
    
    if request.method == 'POST':
        booking_date_str = request.form.get('booking_date')
        num_people = int(request.form.get('num_people'))
        
        # Convert string date to Python date object
        booking_date = datetime.strptime(booking_date_str, '%Y-%m-%d').date()
        
        # Calculate total price based on number of people
        total_price = listing.price * num_people
        
        new_booking = Booking(
            booking_date=booking_date,
            num_people=num_people,
            total_price=total_price,
            user_id=current_user.id,
            listing_id=listing.id
        )
        
        db.session.add(new_booking)
        db.session.commit()
        
        flash('Booking created successfully!')
        return redirect(url_for('bookings.index'))
        
    return render_template('bookings/create.html', listing=listing)

@bookings_bp.route('/<int:id>')
@login_required
def show(id):
    booking = Booking.query.get_or_404(id)
    
    # Ensure the user can only view their own bookings
    if booking.user_id != current_user.id and current_user.user_type != 'admin':
        flash('You do not have permission to view this booking.')
        return redirect(url_for('bookings.index'))
        
    return render_template('bookings/show.html', booking=booking)

@bookings_bp.route('/<int:id>/cancel', methods=['POST'])
@login_required
def cancel(id):
    booking = Booking.query.get_or_404(id)
    
    # Ensure the user can only cancel their own bookings
    if booking.user_id != current_user.id and current_user.user_type != 'admin':
        flash('You do not have permission to cancel this booking.')
        return redirect(url_for('bookings.index'))
        
    booking.status = 'cancelled'
    db.session.commit()
    
    flash('Booking cancelled successfully.')
    return redirect(url_for('bookings.index'))
